# Gap report validation — 7 Sep 2026

Cursor report: `Collector_Software_and_Data_Gap_2026-09-07.md`  
Code zip: `collector_program_code_2026-09-07.zip`  
Authority: `Collector_Requirements_Initial_and_Runtime_Locked_2026-09-04`

Walkthrough tickers used in earlier research are **not** identity templates. Do not copy one issuer’s provider, underlying, inception, or ROC notice onto another symbol.

## Verdict on the report

**Accept the headline. Do not accept another audit slice.**

The report matches the lock on the scoring split:

- `complete` ≠ `last_run_ok` ≠ ever-ok
- Required Skip is incomplete
- CASH / not-in-scope / BDC may complete without ROC %
- Paid rows are not silently overwritten
- Yahoo / nasdaq / dividendinvestor are not declaration sources

Live book as reported: **43 ever-ok, 41 complete, 32 last-run ok / 11 miss.** That is consistent with the lock. Fixture green is still not the gate.

Two names are incomplete. One is missing identity fields the owner must set in the app. One has frequency None and no stored pays because the adapter hit the wrong page. Neither is a reason to rewrite roc_scope or to copy another product’s characteristics.

## Did the D1–D5 prompt actually ship?

Checked in this zip’s `collector.rs`, `div1.rs`, `retrieve/mod.rs`.

| Slice item | Shipped? | Evidence |
|---|---|---|
| D1 `roc_scope` | **Yes** | `RocScope { Cash, NotInScope, Bdc1099, InScope }`. MLP / owner-ordinary / CASH skip 19a-1. BDC is Bdc1099. Complete-gate does not push `roc_estimate` when scope skips. |
| D2 remaining-year vs issuer dates | **Yes in the gate** | `remaining_year_matches` compares `planned_remaining` to `issuer_remaining`. Calendar helper is derive-once only. |
| D3 working seeds | **Partial** | Templates have URLs. Last run still “Issuer page empty” on several standing hosts. One leveraged name is pointed at a family hub instead of its own product table. |
| D4/D5 banned hosts | **Yes** | `is_third_party_declaration_url` includes yahoo + nasdaq + dividendinvestor. Retrieve drops those URLs before persist. |

The fleet looking “more complete” (41/43 vs many Ready=No on 6 Sep) is **real scoring progress**, not a fake green.

## Report items that are correct vs lock

1. Empty-page last_run on names that already have pays is an **adapter hole**, not “no history.”
2. C5 / history-drop treating a short current page as a wipe violates §3.2 / §4.2.
3. Lookback must use **stored** paid count. Feeding this-page count is a software defect.
4. Stale “expected 4” tickets after D2 are leftover tickets, not missing D2 code. Do not invent December.
5. InScope names with a stored percent and empty `roc_source_url` are a real §3.4 hole. **Park that slice.** Do not mix it with empty-page repair.
6. Owner identity and amount clicks stay owner clicks. Do not persist from a pack.

## Report items that are overstated or wrong

| Claim | Correction |
|---|---|
| One leveraged name “never paid” | Its own product page prints a 2026 income amount. Adapter is on the family hub / empty parse. Frequency stays None. ROC stays not-in-scope. Do not take an aggregator amount. |
| 11 last_run misses mean collectors are not established | Lock: last_run is Step A runtime. Most of those misses are still **complete=Y**. That is intended. |
| Fleet-wide 19a-1 URL backfill is the next gate | Too wide for one slice. Scope already skips MLP / ordinary / CASH / BDC. |
| Unparseable increment ticket while last_run=Y | Ticket hygiene. Not Phase I incomplete. |

## Are we making progress or doomed?

**Progress.** The 6 Sep loop was “complete-gate scores the wrong thing.” That gate is now mostly right.

**The loop continues if the next Cursor job is another gap report, or if a walkthrough ticker is treated as a template for other names.**

Next slice is adapter last_run repair only: stored lookback count, C5 short-page, empty-page parse on the standing host, close leftover “expected 4” tickets.

| Who | Work |
|---|---|
| Cursor | Four defects in `CURSOR_ADAPTER_REPAIR_SLICE_2026-09-07.md` |
| Owner, in the app | Identity and amount tickets on the two incomplete / ticketed names. Not via Cursor persist. |
| Later | `roc_source_url` reuse templates; 0-miss ops gate; 1099 process |

Done for this slice is: Run misses only no longer fails because the page was empty or short, and stored history is not wiped.
