# PASTE THIS INTO CURSOR

Attach only:
- Collector_Requirements_Initial_and_Runtime_Locked_2026-09-04.docx
- Collector_Gap_Report_Validation_2026-09-07.md
- CURSOR_ADAPTER_REPAIR_SLICE_2026-09-07.md

Then paste:

Confirmed. Do not write another gap report.

Build only the four items in CURSOR_ADAPTER_REPAIR_SLICE_2026-09-07.md:
1. Lookback uses stored paid count, not this-page count
2. C5 short increment page cannot fail last_run or wipe stored pays
3. Empty-page last_run on the standing same-host seed already on the template (two tries, no proxy)
4. Close stale “expected 4” tickets. Do not invent December.

Walkthrough tickers are not fixtures. Do not copy one issuer’s provider, underlying, inception, or ROC notice onto another symbol. Tests stay NEW1 / PAY1 / CASH1 / MLP1 / ORD1.

Do not persist owner identity or amount clicks. Do not reopen D1/D2/D4/D5. Stop when goldens pass and return a 10-line evidence list.
