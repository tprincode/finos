# Cursor slice — adapter last_run repair only

Confirmed scope. Do **not** write another gap report. Do **not** plan 0-miss as Done. Do **not** persist owner identity or amount clicks.

Authority (already in repo — do not invent a second spec):
- Collector requirements lock extracts under docs/Authority or docs/authority
- Collector_Gap_Report_Validation_2026-09-07.md

Live SQLite is the system of record. Fixture green is not the gate.

## Hard rule on examples vs facts

Walkthrough names are not fixtures and not identity templates.

- Tests and goldens stay **NEW1 / PAY1 / CASH1 / MLP1 / ORD1** only.
- Do not hard-code a household ticker into `roc_scope`, adapters, goldens, or seed defaults.
- Do not copy one issuer’s provider, underlying, inception, frequency, ROC %, or 19a-1 URL onto a different symbol.
- Do not treat “covered-call,” “Amplify,” or any one product page as a fact about an unrelated ticker.
- `roc_scope` is structure + owner lock list already in code. Do not add walkthrough tickers to that list in this slice.

## Already shipped — do not reopen

D1 roc_scope. D2 remaining-year vs issuer dates. D4/D5 banned hosts.
Lot gate. last_run_ok meaning. CASH column.
Cadence locks already in code (do not rewrite the list in this slice).
Owner ordinary / MLP / BDC skips already in code. Plan $. Paid-row overwrite. 9-step wizard. Proxy.

Do not persist owner clicks from this prompt (div_type, inception, ROC accept, amount Except/Reject, payable supersede). Leave those tickets open.

## Build these four defects only

### 1. Lookback uses stored paid count, not this-page count

`validate_paid_lookback` / last_run lookback ticket must use stored `issuer_declaration` paid rows for that symbol.

A name with hundreds of stored pays must not open “6 of 12” because this page parsed six rows.
This-page count may be logged. It must not drive lookback or last_run_ok.

Golden: PAY1 with 12 stored pays and a retrieve that parses 3 rows this page → lookback Complete. last_run may be ok if C5 overlap rule passes.

### 2. C5 / history-drop cannot fail last_run or wipe on a short increment page

Compare overlapping payable dates only.
- New unpaid payable dates: persist.
- Amount change on an already-paid row: ticket. Do not overwrite.
- Dates present in SQLite and absent from this page: keep stored rows. Do not open history-drop as last_run fail.
- Do not replace a stored paid amount with a later issuer print in this slice.

Golden: PAY1 12 stored; page returns 2 latest rows including one amount change → ticket amount_variation, last_run ok, stored count still 12.

### 3. Empty-page last_run — same host, two URL tries, no proxy

Repair parse or seed so a standing vendor page is not reported empty when that host prints a table.

Use the **template `source_url` already stored for that symbol**. Second try must be same host. 403 = `blocked: cloudflare_403` + human URL. JS-only empty body = `blocked: js_empty` + URL. Never invent 0% ROC. No Yahoo / nasdaq.com / dividendinvestor.com.

Known same-host corrections (do not copy these onto other tickers):

| Adapter host | If last_run is “Issuer page empty,” try |
|---|---|
| Gladstone | newsroom press page, then newsroom index. Not a third-party dividend widget. |
| REX / T-Rex MSTU | product page `https://www.rexshares.com/mstu/` (not the family hub that has no MSTU table). Issuer print on that page: $0.0279 payable 2026-08-26. Frequency stays None. ROC stays not-in-scope. Not aggregator $0.2880. |
| Global X QYLD | filings-and-tax-supplements path on globalxetfs.com |
| Simplify SVOL | `https://www.simplify.us/etfs/536/distributions` if the short product table would drop stored history |
| JPMorgan JEPQ | keep the long product slug. Dates-only PDF is not a $/share table. last_run may stay fail until a same-host $ table exists. |
| Direxion | existing product slugs already on the template. 403 is a loud miss. |
| Ellington / Energy Transfer / MPLX | standing IR URLs already on the template. 403 is a loud miss, not ROC work. |

If HTML is JS-only, fail loud. Do not scrape a third-party calendar to fill it.

### 4. Close stale “expected 4” remaining-year tickets

If stored unoccurred dates through 31 Dec match the issuer list, 3 remaining on a monthly name is allowed. Close or rewrite the leftover “expected 4” ticket. Do not insert a December date to make the count 4.

## Tests

```
cargo test -p financial-domain
cargo test -p golden-harness --test collectors --test new_investment --test add_lot
```

Add goldens on generic names only (items 1 and 2).
MLP1 / ORD1 complete Y without roc_pct must still pass.

## Desktop after (owner runs)

Reload fleet. Run misses only.
- Lookback must use stored paid count.
- Stored paid amounts and paid-row counts stay.
- MSTU may store the 2026-08-26 $0.0279 special from rexshares.com/mstu/. Frequency still None. No ROC %.
- No new invented December 2026 dates.
- No identity field written (div_type, inception, underlying, provider, ROC accept).

## Do not build

Another fleet audit. 0-miss ops gate. roc_source_url backfill. 1099 process. Manual adapter. CASH→DIV-2. Auto-tier. Proxy. Wizard rewrite. Owner-click persistence. Walkthrough-ticker fixtures.

When tests pass, stop. Return a 10-line evidence list (files touched + golden names). No 25-page report.
