# PASTE THIS INTO CURSOR — one slice only

You are implementing one collector slice against locked requirements. Do not invent a second spec. Do not reopen closed gates.

## Attach / open these three files first

1. Collector_Requirements_Initial_and_Runtime_Locked_2026-09-04.docx
2. Collector_Code_vs_Cursor_Gap_Assessment_2026-09-06.docx
3. collector_remaining_pack_2026-09-06.json  (issuer facts only — do not overwrite stored paid rows from this file)

Live SQLite is the system of record. Fixture green is not the gate.
Live household tickers may appear in seed URL tables. Tests stay NEW1 / PAY1 / CASH1 / MLP1 / ORD1.

## Do not reopen

Lot gate, last_run_ok meaning, CASH column, cadence locks (AMDW QDTE RDTE TOPW XDTE YBTC Weekly; XPAY Monthly), AMDW 100% ROC, TSLL/MPLX/MSTU/SOXL ROC lock, Plan $, paid-row overwrite, 9-step wizard, proxy.

Do not persist owner clicks from this prompt: HAKY DIV-1, HAKY inception, HAKY 100% accept, TSPY 0.2954 overwrite, IGLD/QDVO Except.

## Build these five defects only

### D1 — roc_scope before any 19a-1 fetch

Add first-class scope. Complete-gate and Fill-gaps must use it.

- CASH (SPAXX FDRXX SWVXX): skip. Already true.
- MLP / LP (EPD ET MPLX): roc_scope=not-in-scope. No 19a-1. Never write ROC %. Complete without roc_pct = yes.
- Owner ordinary lock (TSLL SOXL MSTU): same. Do not write 0%.
- BDC (GLAD): bdc-1099. No monthly 19a-1 filename hunt. Do not invent 0.
- Covered-call / weekly-pay RIC ETF (HAKY QYLD AMDW TSPY SVOL Roundhill WeeklyPay): in-scope. Parse only.

needs_roc_research_on_create is false when roc_scope is not-in-scope or CASH.
runtime_research_gaps.roc_estimate_blank is false when not-in-scope or CASH.
collector_status must not push roc_estimate when not-in-scope.

Pre-validate from issuer page + structure keywords (MLP, K-1, partnership, limited partnership, 1940 Act ETF, covered call, 19a-1). Do not guess 0%.

### D2 — remaining-year uses issuer dates, not calendar months left

remaining_periods_to_year_end("2026-09-06", 12) == 4 is calendar math (Sep–Dec). That number must not fail a monthly name whose issuer already paid September and lists only Oct/Nov/Dec.

Ticket planned-count only when stored unoccurred dates through 31 Dec disagree with the issuer list (or with derive-once when the issuer published none).

Do not insert a fourth 2026 date to make the count 4.

stored_remaining_planned already counts unoccurred stored dates. Prefer that vs issuer list. Calendar helper may stay for derive-once on Phase I when the vendor published no future dates.

### D3 — seed / probe URLs (same host, no proxy)

- GLAD: https://www.gladstonecapital.com/newsroom/detail/394/gladstone-capital-announces-monthly-cash-distributions-for then newsroom index. Not the QuoteMedia widget.
- MPLX: https://ir.mplx.com/CorporateProfile/stock-information/stock-information/default.aspx — 403 is last_run fail, not ROC work.
- JEPQ: keep long product slug. Calendar PDF is dates-only. last_run stays fail until a same-host $/share table exists. No Yahoo.
- QYLD: https://www.globalxetfs.com/filings-and-tax-supplements/qyld + assets.globalxetfs.com Form-19a.
- SVOL: https://www.simplify.us/etfs/536/distributions — do not wipe 64 stored pays from the short product table.
- TSLL: https://www.direxion.com/product/daily-tsla-bull-and-bear-leveraged-single-stock-etfs — do not change ROC.
- SOXL: https://www.direxion.com/product/daily-semiconductor-bull-3x-etf — do not invent 2026 dates.
- MSTU: https://www.rexshares.com/mstu/ — issuer prints $0.0279 payable 2026-08-26. Do not use aggregator $0.2880. Frequency stays None.
- TSPY: existing supabase fund-public-api?ticker=TSPY&view=all. Do not overwrite 2026-09-02 stored 0.30007.

Cloudflare 403: record blocked: cloudflare_403 + the human URL. No proxy.

### D4 / D5 — Yahoo / nasdaq / dividendinvestor are not declaration sources

- live_market_snapshot Yahoo events=div must not become CollectorRetrieve candidates. Price-only snapshot may keep Yahoo without events=div.
- parse_vendor_distributions must not fetch dividendinvestor.com or nasdaq.com. Fixture parsers may stay compiled if fetch is proven dead.
- is_third_party_declaration_url already flags those hosts. Enforce at retrieve, not only at URL-match.

## Tests

cargo test -p financial-domain
cargo test -p golden-harness --test collectors --test new_investment --test add_lot

Add goldens on generic names only:
- MLP1 / ORD1: collector complete can be Y without roc_pct when roc_scope=not-in-scope.
- Monthly PAY1 as-of 2026-09-06 with stored unoccurred 2026-10-15 and 2026-11-13 and no December: 3 remaining is not a remaining_year gap.
- Retrieve of PAY1 must not persist a candidate whose source URL contains yahoo / nasdaq.com / dividendinvestor.

## Desktop after

Reload fleet.
- MPLX / TSLL / SOXL / MSTU / EPD / ET must not list ROC as a gap.
- GLAD last_run may still fail until newsroom parse lands.
- TSPY paid 2026-09-02 amount unchanged.
- HAKY div_type stays empty until owner click.

## Do not build

1099 actual process, manual adapter, CASH→DIV-2 rename, auto-tier, proxy, inventing a fourth 2026 date, overwriting paid rows, rewriting Add Position wizard.
