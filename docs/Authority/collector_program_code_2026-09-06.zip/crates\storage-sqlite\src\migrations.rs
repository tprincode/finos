//! Schema migrations for local SQLite (WAL mode). SQLx migrations land in Milestone 1.

pub const MIGRATIONS_DIR: &str = concat!(env!("CARGO_MANIFEST_DIR"), "/migrations");
