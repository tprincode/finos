//! Post-process checks after a declaration retrieve is stored.
//! Integer math only. Unknown stays unknown — never invent $0 or a cadence.

use crate::calculator::{infer_payment_cadence, PaymentCadence};

/// Owner-named ceiling: a new paid amount may not move more than this percent vs the prior paid.
pub const AMOUNT_VARIATION_PCT: i64 = 30;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PaidDeclarationView<'a> {
    pub payment_period: &'a str,
    pub amount_per_share_minor: Option<i64>,
    pub amount_scale: u8,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PostCheckIssue {
    pub code: &'static str,
    pub message: String,
}

/// `|new - prev| / prev > pct/100` using integers: `|Δ| * 100 > pct * prev`.
/// `None` when prev ≤ 0 (unknown — do not invent a miss or a pass).
pub fn amount_exceeds_variation_pct(new_minor: i64, prev_minor: i64, pct: i64) -> Option<bool> {
    if prev_minor <= 0 || pct < 0 {
        return None;
    }
    let delta = (new_minor as i128 - prev_minor as i128).abs();
    Some(delta.saturating_mul(100) > (prev_minor as i128).saturating_mul(pct as i128))
}

fn period_key(raw: &str) -> String {
    let s = raw.trim();
    if s.len() >= 10 {
        s[..10].to_string()
    } else {
        s.to_string()
    }
}

fn paid_sorted<'a>(rows: &[PaidDeclarationView<'a>]) -> Vec<(String, i64, u8)> {
    let mut out: Vec<(String, i64, u8)> = rows
        .iter()
        .filter_map(|r| {
            let amt = r.amount_per_share_minor.filter(|a| *a > 0)?;
            Some((period_key(r.payment_period), amt, r.amount_scale))
        })
        .collect();
    out.sort_by(|a, b| a.0.cmp(&b.0));
    out
}

fn paid_period_on_page(period: &str, page: &[String]) -> bool {
    if page.iter().any(|p| p == period) {
        return true;
    }
    let Some(stored_day) = crate::week::parse_iso_day(period) else {
        return false;
    };
    let stored_week = crate::week::week_id_containing(stored_day);
    page.iter().any(|p| {
        crate::week::parse_iso_day(p)
            .map(|d| crate::week::week_id_containing(d) == stored_week)
            .unwrap_or(false)
    })
}

/// Stored paid weeks that fall inside this page's date window must still appear.
/// A 3-month press does not drop 1995 seed history. Exact pay date may move by a
/// day (Sat–Fri week) or, on a monthly page, sit on the record date in the same month.
pub fn previous_periods_retained(
    stored_before: &[PaidDeclarationView<'_>],
    reparsed: &[PaidDeclarationView<'_>],
) -> Vec<PostCheckIssue> {
    if reparsed.is_empty() {
        return Vec::new();
    }
    let page: Vec<String> = reparsed
        .iter()
        .filter(|r| r.amount_per_share_minor.map(|a| a > 0).unwrap_or(false))
        .map(|r| period_key(r.payment_period))
        .filter(|p| !p.is_empty())
        .collect();
    let page_days: Vec<_> = page
        .iter()
        .filter_map(|p| crate::week::parse_iso_day(p))
        .collect();
    let window = match (page_days.iter().min(), page_days.iter().max()) {
        (Some(lo), Some(hi)) => Some((*lo, *hi)),
        _ => None,
    };
    let mut month_counts = std::collections::HashMap::<String, usize>::new();
    for p in &page {
        if let Some(m) = year_month(p) {
            *month_counts.entry(m).or_insert(0) += 1;
        }
    }
    let mut issues = Vec::new();
    for row in stored_before {
        if !row.amount_per_share_minor.map(|a| a > 0).unwrap_or(false) {
            continue;
        }
        let p = period_key(row.payment_period);
        if p.is_empty() {
            continue;
        }
        if let Some((lo, hi)) = window {
            let Some(stored_day) = crate::week::parse_iso_day(&p) else {
                continue;
            };
            if stored_day < lo || stored_day > hi {
                continue;
            }
        }
        if paid_period_on_page(&p, &page) {
            continue;
        }
        if year_month(&p)
            .is_some_and(|m| month_counts.get(&m).copied() == Some(1))
        {
            continue;
        }
        issues.push(PostCheckIssue {
            code: "declaration_history_dropped",
            message: format!("stored paid period {p} missing from re-parsed vendor page"),
        });
    }
    issues
}

fn year_month(period: &str) -> Option<String> {
    let d = crate::week::parse_iso_day(period)?;
    Some(d.format("%Y-%m").to_string())
}

/// Locked cadence vs inferred median gap of the newest 12 paid dates.
/// Older quarterly history must not hide a recent monthly switch (TRIN 2026).
pub fn cadence_matches_locked(
    paid_periods: &[&str],
    locked_frequency: &str,
) -> Vec<PostCheckIssue> {
    let Some(locked) = PaymentCadence::parse(locked_frequency).filter(|c| c.periods().is_some())
    else {
        return Vec::new();
    };
    let mut recent: Vec<&str> = paid_periods.to_vec();
    recent.sort_unstable();
    let start = recent.len().saturating_sub(12);
    let recent = &recent[start..];
    let Some(inferred) = infer_payment_cadence(recent, None) else {
        return Vec::new();
    };
    if inferred == locked {
        return Vec::new();
    }
    vec![PostCheckIssue {
        code: "declaration_cadence_mismatch",
        message: format!(
            "Collector paid dates infer {}. Locked cadence is {}. Keeping {} would hide the discovered {} history and can drop or re-group stored paid dates. Change cadence on Position Details (Save replaces cadence) only if the lock is wrong.",
            inferred.label(),
            locked.label(),
            locked.label(),
            inferred.label()
        ),
    }]
}

/// New paid amounts vs the immediately previous paid in date order.
pub fn new_amount_variation_issues(
    newly_posted: &[PaidDeclarationView<'_>],
    stored_after: &[PaidDeclarationView<'_>],
    pct: i64,
) -> Vec<PostCheckIssue> {
    let series = paid_sorted(stored_after);
    let mut issues = Vec::new();
    for row in newly_posted {
        let Some(new_amt) = row.amount_per_share_minor.filter(|a| *a > 0) else {
            continue;
        };
        let period = period_key(row.payment_period);
        if period.is_empty() {
            continue;
        }
        let Some(prev) = series.iter().rev().find(|(p, _, _)| p.as_str() < period.as_str()) else {
            continue;
        };
        if amount_exceeds_variation_pct(new_amt, prev.1, pct) == Some(true) {
            issues.push(PostCheckIssue {
                code: "declaration_amount_variation",
                message: format!(
                    "paid {period} {new_amt} varies more than {pct}% from prior {} {}",
                    prev.0, prev.1
                ),
            });
        }
    }
    issues
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn thirty_percent_is_integer_and_skips_unknown_prev() {
        assert_eq!(amount_exceeds_variation_pct(130, 100, 30), Some(false));
        assert_eq!(amount_exceeds_variation_pct(131, 100, 30), Some(true));
        assert_eq!(amount_exceeds_variation_pct(70, 100, 30), Some(false));
        assert_eq!(amount_exceeds_variation_pct(69, 100, 30), Some(true));
        assert_eq!(amount_exceeds_variation_pct(50, 0, 30), None);
        assert_eq!(amount_exceeds_variation_pct(50, -1, 30), None);
    }

    #[test]
    fn previous_alignment_requires_stored_periods_on_page() {
        let stored = [
            PaidDeclarationView {
                payment_period: "2026-04-30",
                amount_per_share_minor: Some(100),
                amount_scale: 2,
            },
            PaidDeclarationView {
                payment_period: "2026-05-29",
                amount_per_share_minor: Some(100),
                amount_scale: 2,
            },
        ];
        let page = [
            PaidDeclarationView {
                payment_period: "2026-04-30",
                amount_per_share_minor: Some(100),
                amount_scale: 2,
            },
            PaidDeclarationView {
                payment_period: "2026-06-30",
                amount_per_share_minor: Some(100),
                amount_scale: 2,
            },
        ];
        let issues = previous_periods_retained(&stored, &page);
        assert_eq!(issues[0].code, "declaration_history_dropped");
        assert!(issues[0].message.contains("2026-05-29"));
        let kept = [
            PaidDeclarationView {
                payment_period: "2026-04-30",
                amount_per_share_minor: Some(100),
                amount_scale: 2,
            },
            PaidDeclarationView {
                payment_period: "2026-05-29",
                amount_per_share_minor: Some(100),
                amount_scale: 2,
            },
        ];
        assert!(previous_periods_retained(&stored, &kept).is_empty());
        // Same Sat–Fri week: stored Tue 6/2 vs vendor pay Wed 6/3 is a pay-date correction, not a drop.
        let stored_week = [PaidDeclarationView {
            payment_period: "2026-06-03",
            amount_per_share_minor: Some(1818867),
            amount_scale: 6,
        }];
        let page_week = [PaidDeclarationView {
            payment_period: "2026-06-02",
            amount_per_share_minor: Some(1818867),
            amount_scale: 6,
        }];
        assert!(previous_periods_retained(&stored_week, &page_week).is_empty());
        // Quarterly press does not have to restate decades of seed history.
        let old = [PaidDeclarationView {
            payment_period: "2006-11-13",
            amount_per_share_minor: Some(1392),
            amount_scale: 3,
        }];
        let press = [PaidDeclarationView {
            payment_period: "2026-07-31",
            amount_per_share_minor: Some(1215),
            amount_scale: 4,
        }];
        assert!(previous_periods_retained(&old, &press).is_empty());
        // Same month: stored record date vs vendor payable is not a drop.
        let record = [PaidDeclarationView {
            payment_period: "2026-07-15",
            amount_per_share_minor: Some(1215),
            amount_scale: 4,
        }];
        assert!(previous_periods_retained(&record, &press).is_empty());
    }

    #[test]
    fn cadence_monthly_dates_match_locked_monthly() {
        let periods = [
            "2026-01-30",
            "2026-02-27",
            "2026-03-31",
            "2026-04-30",
        ];
        let refs: Vec<&str> = periods.iter().copied().collect();
        assert!(cadence_matches_locked(&refs, "Monthly").is_empty());
        let issues = cadence_matches_locked(&refs, "Weekly");
        assert_eq!(issues[0].code, "declaration_cadence_mismatch");
        assert!(issues[0].message.contains("hide the discovered"));
        assert!(cadence_matches_locked(&["2026-01-30"], "Monthly").is_empty());
    }

    #[test]
    fn recent_monthly_overrides_older_quarterly_history() {
        let periods = [
            "2025-03-31",
            "2025-06-30",
            "2025-09-30",
            "2025-12-31",
            "2026-01-15",
            "2026-02-13",
            "2026-03-13",
            "2026-04-15",
            "2026-05-15",
            "2026-06-11",
            "2026-07-15",
            "2026-08-14",
            "2026-09-10",
        ];
        let refs: Vec<&str> = periods.iter().copied().collect();
        assert!(cadence_matches_locked(&refs, "Monthly").is_empty());
        let issues = cadence_matches_locked(&refs, "Quarterly");
        assert_eq!(issues[0].code, "declaration_cadence_mismatch");
        assert!(issues[0].message.contains("Monthly"));
    }

    #[test]
    fn new_amount_40_pct_vs_prior_fails() {
        let stored = [
            PaidDeclarationView {
                payment_period: "2026-07-31",
                amount_per_share_minor: Some(1000),
                amount_scale: 2,
            },
            PaidDeclarationView {
                payment_period: "2026-08-31",
                amount_per_share_minor: Some(1400),
                amount_scale: 2,
            },
        ];
        let newly = [PaidDeclarationView {
            payment_period: "2026-08-31",
            amount_per_share_minor: Some(1400),
            amount_scale: 2,
        }];
        let issues = new_amount_variation_issues(&newly, &stored, AMOUNT_VARIATION_PCT);
        assert_eq!(issues[0].code, "declaration_amount_variation");
        let ok_new = [PaidDeclarationView {
            payment_period: "2026-08-31",
            amount_per_share_minor: Some(1200),
            amount_scale: 2,
        }];
        let stored_ok = [
            stored[0],
            PaidDeclarationView {
                payment_period: "2026-08-31",
                amount_per_share_minor: Some(1200),
                amount_scale: 2,
            },
        ];
        assert!(new_amount_variation_issues(&ok_new, &stored_ok, AMOUNT_VARIATION_PCT).is_empty());
    }
}
