//! Income Plan week grid and Dashboard burndown account identity (domain docs + BR-X).
//! Plan amounts are not inferred. Missing plan stays unknown — never zero.

use chrono::{Datelike, Duration, Months, NaiveDate};

pub const CONTROL_ACCOUNTS: [&str; 5] = ["Income", "Health", "Roth", "Account 9", "Car"];
pub const BURNDOWN_ACCOUNTS: [&str; 4] = ["Income", "Car", "Health", "Roth"];

/// Percent of plan as scale-2 (10000 = 100.00%). None if plan unknown or plan is 0 — never 0%.
pub fn pct_of_plan_minor(actual_minor: i64, plan_known: bool, planned_minor: i64) -> Option<i64> {
    if !plan_known || planned_minor == 0 {
        return None;
    }
    Some(actual_minor.saturating_mul(10_000) / planned_minor)
}

/// Inclusive start of a performance range. `None` means unbounded (`all`).
pub fn performance_range_start(as_of: NaiveDate, range: &str) -> Result<Option<NaiveDate>, &'static str> {
    match range {
        "30d" => Ok(Some(as_of - Duration::days(30))),
        "60d" => Ok(Some(as_of - Duration::days(60))),
        "90d" => Ok(Some(as_of - Duration::days(90))),
        "1m" => as_of
            .checked_sub_months(Months::new(1))
            .map(Some)
            .ok_or("range_overflow"),
        "2m" => as_of
            .checked_sub_months(Months::new(2))
            .map(Some)
            .ok_or("range_overflow"),
        "3m" => as_of
            .checked_sub_months(Months::new(3))
            .map(Some)
            .ok_or("range_overflow"),
        "ytd" => Ok(NaiveDate::from_ymd_opt(as_of.year(), 1, 1)),
        "all" => Ok(None),
        _ => Err("unknown_range"),
    }
}

/// Map an account name in the data file onto the Income Plan control grid, if it belongs.
pub fn map_control_account(name: &str) -> Option<&'static str> {
    let n = name.trim().to_ascii_lowercase();
    if n == "income" {
        return Some("Income");
    }
    if n.contains("health") || n == "hsa" {
        return Some("Health");
    }
    if n.contains("roth") {
        return Some("Roth");
    }
    if n.contains("account 9") || n == "9" {
        return Some("Account 9");
    }
        if n == "car" || n.starts_with("car ") || n.ends_with(" car") {
        return Some("Car");
    }
    None
}

pub fn is_burndown_account(control: &str) -> bool {
    BURNDOWN_ACCOUNTS.contains(&control)
}

pub fn occurred_in_week(occurred_on: &str, start: &str, end: &str) -> bool {
    let day = if occurred_on.len() >= 10 {
        &occurred_on[..10]
    } else {
        occurred_on
    };
    day >= start && day <= end
}

fn year_month(raw: &str) -> Option<&str> {
    let day = if raw.len() >= 10 { &raw[..10] } else { raw };
    if day.len() >= 7 {
        Some(&day[..7])
    } else {
        None
    }
}

/// Issuer declaration belongs on this week's payable: period in the Sat–Fri week,
/// or same year-month as the week's pay-on.
pub fn declaration_belongs_in_week(
    payment_period: &str,
    week_start: &str,
    week_end: &str,
    pay_on: &str,
) -> bool {
    if occurred_in_week(payment_period, week_start, week_end) {
        return true;
    }
    if pay_on.trim().is_empty() || !occurred_in_week(pay_on, week_start, week_end) {
        return false;
    }
    year_month(payment_period) == year_month(pay_on)
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::NaiveDate;

    #[test]
    fn maps_fi_roth_and_excludes_speculation() {
        assert_eq!(map_control_account("FI Roth"), Some("Roth"));
        assert_eq!(map_control_account("For the CAR"), Some("Car"));
        assert_eq!(map_control_account("Speculation"), None);
        assert!(!is_burndown_account("Account 9"));
        assert!(is_burndown_account("Roth"));
    }

    #[test]
    fn week_filter_uses_iso_dates() {
        assert!(occurred_in_week("2026-08-17", "2026-08-15", "2026-08-21"));
        assert!(!occurred_in_week("2026-08-14", "2026-08-15", "2026-08-21"));
    }

    #[test]
    fn declaration_follows_week_payable_not_a_named_example() {
        assert!(declaration_belongs_in_week(
            "2026-08-31",
            "2026-08-29",
            "2026-09-04",
            "2026-08-31"
        ));
        assert!(declaration_belongs_in_week(
            "2026-08-31",
            "2026-08-22",
            "2026-08-28",
            "2026-08-28"
        ));
        assert!(!declaration_belongs_in_week(
            "2026-07-31",
            "2026-08-29",
            "2026-09-04",
            "2026-08-31"
        ));
    }

    #[test]
    fn pct_of_plan_is_none_when_unknown_or_zero_never_zero_percent() {
        assert_eq!(pct_of_plan_minor(1_650, false, 0), None);
        assert_eq!(pct_of_plan_minor(0, true, 0), None);
        assert_eq!(pct_of_plan_minor(3_500, true, 3_500), Some(10_000));
        assert_eq!(pct_of_plan_minor(3_850, true, 3_500), Some(11_000));
        assert_eq!(pct_of_plan_minor(0, true, 3_500), Some(0));
    }

    #[test]
    fn performance_range_start_covers_days_months_ytd_all() {
        let as_of = NaiveDate::from_ymd_opt(2026, 8, 31).unwrap();
        assert_eq!(
            performance_range_start(as_of, "30d").unwrap(),
            Some(NaiveDate::from_ymd_opt(2026, 8, 1).unwrap())
        );
        assert_eq!(
            performance_range_start(as_of, "1m").unwrap(),
            Some(NaiveDate::from_ymd_opt(2026, 7, 31).unwrap())
        );
        assert_eq!(
            performance_range_start(as_of, "ytd").unwrap(),
            Some(NaiveDate::from_ymd_opt(2026, 1, 1).unwrap())
        );
        assert_eq!(performance_range_start(as_of, "all").unwrap(), None);
        assert!(performance_range_start(as_of, "nope").is_err());
    }
}
